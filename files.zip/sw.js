const CACHE_NAME = 'ilmaliyet-v1-cache-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/taban.json',
  '/icons/icon-192.png',
  '/icons/icon-256.png',
  '/icons/icon-512.png'
];

self.addEventListener('install', (ev) => {
  ev.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (ev) => {
  ev.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(k => { if (k !== CACHE_NAME) return caches.delete(k); }))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (ev) => {
  const req = ev.request;
  // Navigation requests -> network first fallback cache (ensures app loads latest index.html when online)
  if (req.mode === 'navigate') {
    ev.respondWith(
      fetch(req).then(r => {
        // güncel index.html cache'e al
        const copy = r.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(req, copy));
        return r;
      }).catch(() => caches.match('/index.html'))
    );
    return;
  }

  // Diğer istekler için: cache first, sonra ağ (offline performans)
  ev.respondWith(
    caches.match(req).then(cached => cached || fetch(req).then(res => {
      const copy = res.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(req, copy));
      return res;
    })).catch(() => {})
  );
});